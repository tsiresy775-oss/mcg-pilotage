// Génération de la facture de licence au format PDF (d'après le modèle MCG)
const fs = require('fs'), path = require('path');
const PDFDocument = require('pdfkit');

const MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
const cap = x => String(x || '').trim().toLowerCase().replace(/(^|[\s-])(\S)/g, (m, a, b) => a + b.toUpperCase());
const up = x => String(x || '').trim().toUpperCase();

function toDate(v) {
  if (!v) return null;
  if (v instanceof Date) return isNaN(v) ? null : v;
  const s = String(v).trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
  m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/);
  if (m) { let y = +m[3]; if (y < 100) y += y > 30 ? 1900 : 2000; return new Date(y, +m[2] - 1, +m[1]); }
  return null;
}
const frDate = d => `${d.getDate() === 1 ? '1er' : d.getDate()} ${MOIS[d.getMonth()]} ${d.getFullYear()}`;
const frLong = v => { const d = toDate(v); return d ? frDate(d) : String(v || '').trim(); };
const euro = v => {
  const n = parseFloat(String(v == null || v === '' ? 300 : v).replace(/\s/g, '').replace(',', '.'));
  return (isNaN(n) ? 300 : n).toFixed(2).replace('.', ',') + ' €';
};

function fileName(d) {
  const m = String(d.annee || '').match(/\d{4}/);
  const yy = m ? m[0].slice(2) : String(new Date().getFullYear()).slice(2);
  const clean = x => String(x || '').replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '-').trim();
  return `MCG-Facture_licence_${yy}_${clean(up(d.nom))}_${clean(cap(d.prenom))}.pdf`;
}

function buildPdf(d) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 0, info: { Title: 'Facture licence MCG', Author: 'MCG – Mitry Compans Goëlly' } });
    const bufs = []; doc.on('data', b => bufs.push(b)); doc.on('end', () => resolve(Buffer.concat(bufs))); doc.on('error', reject);
    const A = path.join(__dirname, 'invoice-assets');
    const L = 42.5, R = 552.5, K = '#000000';
    const paid = !/(non|attente|r[eè]gler|impay|devoir)/i.test(String(d.statut || ''));
    const annee = d.annee || '2026 / 2027';
    const nomPre = `${up(d.nom)} ${cap(d.prenom)}`;
    const payeur = d.payeur ? (/\s/.test(String(d.payeur).trim()) ? String(d.payeur).trim() : String(d.payeur).trim()) : nomPre;

    doc.fillColor(K);
    // Bloc club (haut gauche)
    let y = 52;
    doc.font('Helvetica-Bold').fontSize(11).text('MITRY COMPANS GOELLY', L, y, { lineBreak: false }); y += 15.5;
    doc.text('Club de Football', L, y, { lineBreak: false }); y += 15.5;
    doc.font('Helvetica').fontSize(11);
    ['8 Rue d’Estienne D’orves', '77290 MITRY-MORY', 'N° AFFILIATION : 548939', 'SIRET : 44297726000029', 'CODE NAF : 9312 Z', 'RNA : W771004549'].forEach(t => { doc.text(t, L, y, { lineBreak: false }); y += 15.5; });
    // Logo
    try { doc.image(path.join(A, 'logo.png'), 424, 44, { width: 126 }); } catch { }

    // Date + destinataire
    const date = d.date ? (toDate(d.date) || new Date()) : new Date();
    doc.font('Helvetica').fontSize(11).text(`Mitry-Mory, le ${frDate(date)}`, 360, 217, { lineBreak: false });
    let ry = 249;
    doc.text(payeur, 360, ry, { lineBreak: false }); ry += 16;
    if (d.rue) { doc.text(String(d.rue).trim(), 360, ry, { lineBreak: false }); ry += 16; }
    const cpv = [d.cp, up(d.ville)].filter(Boolean).join(' ').trim();
    if (cpv) doc.text(cpv, 360, ry, { lineBreak: false });

    // Titre
    doc.font('Helvetica-Bold').fontSize(16);
    const title = paid ? 'FACTURE ACQUITEE' : 'FACTURE';
    const tw = doc.widthOfString(title), tx = (595.28 - tw) / 2, ty = 389;
    doc.text(title, tx, ty, { lineBreak: false });
    doc.moveTo(tx, ty + 19).lineTo(tx + tw, ty + 19).lineWidth(1).strokeColor(K).stroke();

    // Tableau
    const top = 478, c1 = 74, c3 = 106, w = R - L, c2 = w - c1 - c3, hh = 24, bh = 88;
    doc.lineWidth(1).strokeColor(K);
    doc.rect(L, top, w, hh).fillAndStroke('#e8e8e8', K);
    doc.rect(L, top + hh, w, bh).stroke();
    doc.moveTo(L + c1, top).lineTo(L + c1, top + hh + bh).stroke();
    doc.moveTo(L + c1 + c2, top).lineTo(L + c1 + c2, top + hh + bh).stroke();
    doc.fillColor(K).font('Helvetica').fontSize(10.5);
    doc.text('QUANTITE', L, top + 7, { width: c1, align: 'center', lineBreak: false });
    doc.text('DESIGNATION', L + c1, top + 7, { width: c2, align: 'center', lineBreak: false });
    doc.text('PRIX €', L + c1 + c2, top + 7, { width: c3, align: 'center', lineBreak: false });
    doc.fontSize(11).text('1', L, top + hh + bh / 2 - 6, { width: c1, align: 'center', lineBreak: false });
    const lines = [
      'Adhésion au club MCG pour une licence de Football',
      `Année : ${annee}`,
      `N° Licence : ${String(d.licence || '').trim()}`,
      `Nom & Prénom : ${nomPre}`,
      `Date de naissance : ${frLong(d.naissance)}`
    ];
    let ly = top + hh + 8;
    lines.forEach(t => { doc.font('Helvetica').fontSize(11).text(t, L + c1 + 6, ly, { width: c2 - 12, lineBreak: false }); ly += 15.5; });
    doc.font('Helvetica-Bold').fontSize(11).text(euro(d.montant), L + c1 + c2, top + hh + bh / 2 - 6, { width: c3, align: 'center', lineBreak: false });

    // Mention de règlement + tampon
    const fy = top + hh + bh + 22;
    doc.font('Helvetica').fontSize(11).text('Facture : ', L, fy, { continued: true, lineBreak: false });
    doc.font('Helvetica-Bold').text(paid ? 'Payée' : 'À régler', { lineBreak: false });
    try { doc.image(path.join(A, 'tampon.png'), 405, fy - 14, { width: 140 }); } catch { }
    doc.end();
  });
}

module.exports = { buildPdf, fileName, frLong, toDate, cap, up };
