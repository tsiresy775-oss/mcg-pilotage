// Mises à jour : fichier .zip (installation manuelle) ou dépôt GitHub (automatique)
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const AdmZip = require('adm-zip');

const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; };
const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');
const baseDir = userData => path.join(userData, 'update');

function installZip(buf, userData, current, expectedSha) {
  if (expectedSha && sha256(buf) !== String(expectedSha).toLowerCase()) throw new Error('Empreinte du fichier invalide : mise à jour refusée');
  let zip; try { zip = new AdmZip(buf); } catch { throw new Error('Ce fichier n’est pas une archive zip valide'); }
  for (const e of zip.getEntries()) {
    const n = e.entryName.replace(/\\/g, '/');
    if (n.startsWith('/') || /^[a-zA-Z]:/.test(n) || n.split('/').includes('..')) throw new Error('Archive refusée (chemin non autorisé)');
  }
  const ve = zip.getEntry('version.json'), ce = zip.getEntry('core.js');
  if (!ve || !ce) throw new Error('Ce fichier n’est pas une mise à jour MCG FC Planner');
  let ver; try { ver = JSON.parse(ve.getData().toString('utf8')).version; } catch { ver = ''; }
  if (!/^\d+\.\d+\.\d+$/.test(ver)) throw new Error('Numéro de version illisible');
  if (cmp(ver, current) <= 0) return { status: 'up_to_date', version: ver, current };
  const base = baseDir(userData), tmp = path.join(base, ver + '.tmp'), fin = path.join(base, ver);
  fs.mkdirSync(base, { recursive: true });
  fs.rmSync(tmp, { recursive: true, force: true }); fs.rmSync(fin, { recursive: true, force: true });
  zip.extractAllTo(tmp, true);
  fs.renameSync(tmp, fin);
  fs.writeFileSync(path.join(base, 'current.json'), JSON.stringify({ version: ver }));
  for (const d of fs.readdirSync(base)) if (d !== ver && d !== 'current.json') fs.rmSync(path.join(base, d), { recursive: true, force: true });
  return { status: 'installed', version: ver };
}

async function fetchBuf(url) {
  const r = await fetch(url, { headers: { 'User-Agent': 'mcg-fc-planner' } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return Buffer.from(await r.arrayBuffer());
}

// Cherche latest.json dans <dépôt>/update/ puis installe le zip indiqué
async function checkRemote({ repo, base, current, userData }) {
  const root = base || (repo ? `https://raw.githubusercontent.com/${repo}/HEAD/update` : '');
  if (!root) return { status: 'not_configured' };
  let m;
  try { m = JSON.parse((await fetchBuf(root + '/latest.json')).toString('utf8')); }
  catch (e) { return { status: 'unreachable', message: e.message }; }
  if (!/^\d+\.\d+\.\d+$/.test(m.version || '')) return { status: 'unreachable', message: 'manifeste invalide' };
  if (cmp(m.version, current) <= 0) return { status: 'up_to_date', version: m.version, current };
  if (!/^[\w.\-]+\.zip$/.test(m.file || '')) return { status: 'unreachable', message: 'nom de fichier invalide' };
  return installZip(await fetchBuf(root + '/' + m.file), userData, current, m.sha256);
}

module.exports = { cmp, sha256, installZip, checkRemote, baseDir };
