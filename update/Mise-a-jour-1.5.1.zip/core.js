// MCG Pilotage - cœur de l'application (chargé par main.js, remplaçable par mise à jour)
const { app, BrowserWindow, Tray, Menu, nativeImage, shell, dialog, Notification } = require('electron');
const path = require('path'), fs = require('fs');

exports.start = function start(ctx) {
  const { createServer } = require(path.join(ctx.appDir, 'server.js'));
  const updater = require(path.join(ctx.appDir, 'updater.js'));
  const version = JSON.parse(fs.readFileSync(path.join(ctx.appDir, 'version.json'), 'utf8'));
  const userData = app.getPath('userData');
  let win, tray, quitting = false, baseUrl = '', updating = false;
  const icon = () => nativeImage.createFromPath(path.join(ctx.bundledDir, 'assets', 'icon.png'));
  const readClient = () => { try { return JSON.parse(fs.readFileSync(path.join(userData, 'client.json'), 'utf8')); } catch { return {}; } };
  const readCfg = () => { try { return JSON.parse(fs.readFileSync(path.join(userData, 'config.json'), 'utf8')); } catch { return {}; } };
  const note = (title, body) => { if (Notification.isSupported()) new Notification({ title, body, icon: icon() }).show(); };

  function openWindow() {
    if (win && !win.isDestroyed()) { win.show(); win.focus(); return; }
    win = new BrowserWindow({ width: 1100, height: 780, title: 'MCG Pilotage', autoHideMenuBar: false, icon: icon(), backgroundColor: '#0d0d0d',
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
    const first = !readClient().serverUrl && !fs.existsSync(path.join(userData, 'config.json'));
    win.on('page-title-updated', e => e.preventDefault());
    win.setTitle('MCG Pilotage — version ' + version.version);
    win.loadURL(first ? baseUrl + '/admin' : baseUrl);
    win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url) && !url.startsWith(baseUrl)) shell.openExternal(url); return { action: 'deny' }; });
    win.webContents.on('did-fail-load', () => win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent('<body style="background:#0d0d0d;color:#ffd60a;font-family:sans-serif;padding:40px"><h2>Serveur injoignable</h2><p>Vérifie que le PC serveur est allumé et que l’adresse est correcte.<br>Adresse utilisée : ' + baseUrl + '</p></body>')));
    const nav = () => win && !win.isDestroyed() && win.webContents;
    win.on('app-command', (e, cmd) => { const w = nav(); if (!w) return; if (cmd === 'browser-backward' && w.canGoBack()) w.goBack(); if (cmd === 'browser-forward' && w.canGoForward()) w.goForward(); });
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { label: '← Retour', accelerator: 'Alt+Left', click: () => { const w = nav(); if (w && w.canGoBack()) w.goBack(); else if (w) win.loadURL(baseUrl); } },
      { label: 'Avancer →', accelerator: 'Alt+Right', click: () => { const w = nav(); if (w && w.canGoForward()) w.goForward(); } },
      { label: '🏠 Accueil', click: () => win && win.loadURL(baseUrl) },
      { label: '⚙️ Configuration', click: () => win && win.loadURL(baseUrl + '/admin') },
      { label: '↻ Actualiser', accelerator: 'F5', click: () => { const w = nav(); if (w) w.reload(); } }
    ]));
    win.on('close', e => { if (!quitting) { e.preventDefault(); win.hide(); } });
  }

  function relaunchSoon(version) {
    note('MCG Pilotage mis à jour', 'Version ' + version + ' installée. Redémarrage…');
    setTimeout(() => { quitting = true; app.relaunch(); app.quit(); }, 4000);
  }
  async function checkUpdate(manual) {
    if (updating) return { status: 'busy' };
    updating = true;
    try {
      const repo = readCfg().updateRepo || version.updateRepo || '';
      const r = await updater.checkRemote({ repo, base: process.env.MCG_UPDATE_BASE, current: version.version, userData });
      if (r.status === 'installed') relaunchSoon(r.version);
      else if (manual) {
        const txt = { up_to_date: 'Tu as déjà la dernière version (' + version.version + ').', not_configured: 'Aucun dépôt de mises à jour n’est configuré.', unreachable: 'Mises à jour injoignables : ' + (r.message || '') }[r.status] || r.status;
        dialog.showMessageBox({ type: 'info', title: 'Mises à jour', message: txt });
      }
      return r;
    } catch (e) { if (manual) dialog.showErrorBox('Mise à jour impossible', e.message); return { status: 'error', message: e.message }; }
    finally { updating = false; }
  }
  const updaterApi = {
    check: () => checkUpdate(false),
    installBase64: async data => {
      const r = updater.installZip(Buffer.from(String(data || ''), 'base64'), userData, version.version);
      if (r.status === 'installed') relaunchSoon(r.version);
      return r;
    }
  };
  async function installFromFile() {
    const f = await dialog.showOpenDialog({ title: 'Choisir le fichier de mise à jour', filters: [{ name: 'Mise à jour MCG Pilotage', extensions: ['zip'] }], properties: ['openFile'] });
    if (f.canceled || !f.filePaths[0]) return;
    try {
      const r = updater.installZip(fs.readFileSync(f.filePaths[0]), userData, version.version);
      if (r.status === 'installed') relaunchSoon(r.version);
      else dialog.showMessageBox({ type: 'info', title: 'Mises à jour', message: 'Ce fichier (' + r.version + ') n’est pas plus récent que ta version (' + version.version + ').' });
    } catch (e) { dialog.showErrorBox('Mise à jour refusée', e.message); }
  }
  function revertToBundled() {
    try { fs.rmSync(path.join(userData, 'update'), { recursive: true, force: true }); } catch {}
    quitting = true; app.relaunch(); app.quit();
  }

  const lock = app.requestSingleInstanceLock();
  if (!lock) { app.quit(); return; }
  app.on('second-instance', openWindow);
  app.whenReady().then(async () => {
    app.setAppUserModelId('com.mcg.pilotage');
    const client = readClient();
    let serverLabel;
    if (client.serverUrl) { baseUrl = client.serverUrl.replace(/\/$/, ''); serverLabel = 'Client : ' + baseUrl; }
    else {
      try { const info = await createServer(userData, { appDir: ctx.appDir, version: version.version, updater: updaterApi }).start(); baseUrl = 'http://localhost:' + info.port; serverLabel = 'Serveur : ' + (info.urls[0] || baseUrl); }
      catch (e) { baseUrl = 'http://localhost:3300'; serverLabel = 'Serveur déjà lancé ou port occupé'; }
    }
    tray = new Tray(icon().resize({ width: 16, height: 16 }));
    tray.setToolTip('MCG Pilotage ' + version.version);
    tray.on('click', openWindow);
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Ouvrir MCG Pilotage', click: openWindow },
      { label: serverLabel, enabled: false },
      { label: 'Version ' + version.version, enabled: false },
      ...(client.serverUrl ? [] : [{ label: 'Configuration (boîtes mail, calendrier, mises à jour)…', click: () => shell.openExternal(baseUrl + '/admin') }]),
      { type: 'separator' },
      { label: 'Installer sur l’iPhone (QR code)…', click: () => shell.openExternal('http://localhost:' + (baseUrl.split(':').pop() || 3300) + '/qr') },
      { label: 'Rechercher une mise à jour', click: () => checkUpdate(true) },
      { label: 'Installer un fichier de mise à jour…', click: installFromFile },
      ...(ctx.appDir !== ctx.bundledDir ? [{ label: 'Revenir à la version d’origine', click: revertToBundled }] : []),
      { type: 'separator' },
      { label: 'Ouvrir le journal des erreurs', click: () => { const f = path.join(userData, 'erreurs.log'); fs.existsSync(f) ? shell.openPath(f) : dialog.showMessageBox({ message: 'Aucune erreur enregistrée.' }); } },
      { label: 'Ouvrir le dossier des données', click: () => shell.openPath(userData) },
      { label: 'Quitter', click: () => { quitting = true; app.quit(); } }
    ]));
    app.setLoginItemSettings({ openAtLogin: true });
    openWindow();
    if (!client.serverUrl) { setTimeout(() => checkUpdate(false), 20000); setInterval(() => checkUpdate(false), 6 * 3600 * 1000); }
  });
  app.on('before-quit', () => { quitting = true; });
  app.on('window-all-closed', e => e.preventDefault());
};
