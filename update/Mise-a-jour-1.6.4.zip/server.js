// MCG Pilotage - serveur intranet (données partagées + 2 boîtes Gmail + calendrier)
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { ImapFlow } = require('imapflow');
const nodemailer = require('nodemailer');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon', '.svg': 'image/svg+xml' };
// Boîte du club : mails non lus de la FFF / ligue / district + sujets licences, commissions, amendes...
const DEFAULT_CLUB_QUERY = 'is:unread -from:footamateur.fff.fr -from:nike.footamateur.fff.fr (from:lpiff.fr OR from:fff.fr OR from:seineetmarne.fff.fr OR licence OR licences OR commission OR amende OR amendes OR discipline OR sanction OR sanctions OR mutation OR affiliation OR engagement OR forfait OR footclubs OR "feuille de match" OR "pôle licences" OR "rappel à l\'ordre")';

function createServer(dataDir, opts = {}) {
  const root = opts.appDir || __dirname;
  fs.mkdirSync(dataDir, { recursive: true });
  const cfgFile = path.join(dataDir, 'config.json'), dbFile = path.join(dataDir, 'data.json');
  const readJ = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
  const loadCfg = () => Object.assign({ port: 3300, email: '', appPassword: '', clubEmail: '548939@lpiff.fr', clubPassword: '', clubQuery: '', icsUrl: '', accessCode: '', updateRepo: '' }, readJ(cfgFile, {}));
  let db = readJ(dbFile, {}), saveT = null;
  const save = () => { clearTimeout(saveT); saveT = setTimeout(() => fs.writeFile(dbFile + '.tmp', JSON.stringify(db), e => { if (!e) fs.rename(dbFile + '.tmp', dbFile, () => {}); }), 200); };

  /* ---------- Gmail (IMAP / SMTP avec mot de passe d'application) ---------- */
  const err = (code, message) => Object.assign(new Error(message || code), { code });
  const splitId = id => { id = String(id || ''); return id.startsWith('club:') ? { account: 'club', tid: id.slice(5) } : { account: 'main', tid: id }; };
  function creds(account) {
    const c = loadCfg();
    const e = account === 'club' ? c.clubEmail : c.email, p = account === 'club' ? c.clubPassword : c.appPassword;
    if (!e || !p) throw err('not_configured', account === 'club' ? 'Boîte du club non configurée (voir /admin)' : 'Gmail non configuré (voir /admin)');
    return { email: e, pass: p };
  }
  async function withImap(account, fn) {
    const c = creds(account);
    const client = new ImapFlow({ host: 'imap.gmail.com', port: 993, secure: true, auth: { user: c.email, pass: c.pass }, logger: false });
    client.on('error', () => {});
    try { await client.connect(); } catch (e) { const raw = String(e.responseText || e.response || e.message || e.code || 'erreur inconnue').slice(0, 300); throw err('needs_reauth', 'Connexion refusée par Google pour ' + c.email + ' — ' + (e.authenticationFailed ? 'mot de passe d’application refusé' : 'connexion impossible') + ' (' + raw + '). Vérifie le mot de passe d’application, ou que la validation en deux étapes et IMAP sont autorisés sur ce compte.'); }
    try { return await fn(client, c); } finally { await client.logout().catch(() => {}); }
  }
  async function allMailPath(client) {
    const boxes = await client.list();
    const b = boxes.find(x => x.specialUse === '\\All');
    return b ? b.path : 'INBOX';
  }
  const viewUrl = (email, tid) => `https://mail.google.com/mail/?authuser=${encodeURIComponent(email)}#all/${BigInt(tid).toString(16)}`;
  async function searchThreads(a) {
    const hasClub = !!(loadCfg().clubEmail && loadCfg().clubPassword);
    const account = (a.account === 'club' && hasClub) ? 'club' : 'main';
    return withImap(account, async (client, c) => {
      const lock = await client.getMailboxLock(await allMailPath(client));
      try {
        const q = account === 'club' ? (loadCfg().clubQuery || a.query || DEFAULT_CLUB_QUERY) : (a.query || 'is:unread');
        const uids = await client.search({ gmraw: q }, { uid: true });
        const take = (uids || []).slice(-(a.pageSize || 30));
        if (!take.length) return { threads: [] };
        const threads = new Map(), pre = account === 'club' ? 'club:' : '';
        for await (const m of client.fetch(take.join(','), { envelope: true, threadId: true }, { uid: true })) {
          const tid = String(m.threadId || m.uid), f = (m.envelope.from && m.envelope.from[0]) || {};
          if (!threads.has(tid)) threads.set(tid, { id: pre + tid, viewUrl: /^\d+$/.test(tid) ? viewUrl(c.email, tid) : '', messages: [] });
          threads.get(tid).messages.push({ id: String(m.uid), subject: m.envelope.subject || '', date: m.envelope.date ? new Date(m.envelope.date).toISOString() : '', sender: f.address || '', addressDisplayNames: [{ emailAddress: f.address || '', displayName: f.name || '' }] });
        }
        const out = [...threads.values()];
        out.forEach(t => t.messages.sort((x, y) => new Date(x.date) - new Date(y.date)));
        out.sort((x, y) => new Date(y.messages.slice(-1)[0].date) - new Date(x.messages.slice(-1)[0].date));
        return { threads: out };
      } finally { lock.release(); }
    });
  }
  async function markRead(a) {
    const { account, tid } = splitId(a.threadId);
    return withImap(account, async (client) => {
      const lock = await client.getMailboxLock(await allMailPath(client));
      try {
        const uids = await client.search({ threadId: tid }, { uid: true });
        if (uids && uids.length) await client.messageFlagsAdd(uids.join(','), ['\\Seen'], { uid: true });
        return { ok: true };
      } finally { lock.release(); }
    });
  }
  /* ---------- Facture PDF : création, enregistrement sur le PC, envoi avec pièce jointe ---------- */
  function invoiceDir() {
    const c = loadCfg(); if (c.invoiceDir) return c.invoiceDir;
    let docs; try { docs = require('electron').app.getPath('documents'); } catch { docs = path.join(require('os').homedir(), 'Documents'); }
    return path.join(docs, 'MCG Factures');
  }
  async function sendInvoice(a) {
    const inv = require('./invoice.js'), d = a.invoice || {};
    if (!String(d.nom || '').trim() || !String(d.prenom || '').trim()) throw err('bad_request', 'Nom et prénom du joueur manquants');
    const pdf = await inv.buildPdf(d), name = inv.fileName(d), dir = invoiceDir();
    try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(path.join(dir, name), pdf); }
    catch (e) { throw err('save_failed', 'Enregistrement du PDF impossible dans « ' + dir + ' » : ' + e.message); }
    const to = (a.to || []).filter(Boolean);
    if (!to.length) return { file: name, dir, sent: false };
    let c; try { c = creds('club'); } catch { c = creds('main'); }
    const tr = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 465, secure: true, auth: { user: c.email, pass: c.pass } });
    const esc = x => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const body = String(a.body || '').replace(/\n+(SECRETARIAT|MARCEL C\.)[\s\S]*$/, '');
    const html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#111">' + esc(body).replace(/\n/g, '<br>') + '<br><br><img src="cid:signature-mcg" width="560" style="max-width:100%;height:auto" alt="MCG – Secrétariat"></div>';
    const atts = [{ filename: name, content: pdf, contentType: 'application/pdf' }];
    try { atts.push({ filename: 'signature.png', path: path.join(__dirname, 'invoice-assets', 'signature.png'), cid: 'signature-mcg', contentDisposition: 'inline' }); } catch {}
    try { await tr.sendMail({ from: c.email, to: to.join(','), subject: a.subject || '', text: body + '\n\nSECRETARIAT\nMitry Compans Goëlly – MCG 548939\nMail Club : 548939@lpiff.fr\nFacebook : mitrycompansgoelly\nInstagram : mcg_mitrymory_football', html, attachments: atts }); }
    catch (e) { throw err('send_failed', 'PDF enregistré (' + name + ') mais mail non envoyé : ' + e.message); }
    return { file: name, dir, sent: true };
  }
  async function sendMessage(a) {
    let c; try { c = creds('club'); } catch { c = creds('main'); }
    const to = (a.to || []).filter(Boolean);
    if (!to.length) throw err('bad_request', 'Destinataire manquant');
    const tr = nodemailer.createTransport({ host: 'smtp.gmail.com', port: 465, secure: true, auth: { user: c.email, pass: c.pass } });
    try { const r = await tr.sendMail({ from: c.email, to: to.join(','), subject: a.subject || '', text: a.body || '' }); return { id: r.messageId }; }
    catch (e) { throw err('send_failed', e.message); }
  }

  /* ---------- Calendrier (lien ICS SportEasy / Google) ---------- */
  let icsCache = { at: 0, url: '', events: [] };
  const unesc = s => (s || '').replace(/\\n/gi, '\n').replace(/\\([,;\\])/g, '$1');
  function icsDate(v) {
    const m = /^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})(Z?))?$/.exec(v || '');
    if (!m) return '';
    if (!m[4]) return `${m[1]}-${m[2]}-${m[3]}`;
    if (m[7]) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6])).toLocaleString('sv-SE', { timeZone: 'Europe/Paris' }).replace(' ', 'T');
    return `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}`;
  }
  function parseICS(txt) {
    const lines = txt.replace(/\r?\n[ \t]/g, '').split(/\r?\n/), evs = []; let cur = null;
    for (const ln of lines) {
      if (ln === 'BEGIN:VEVENT') { cur = {}; continue; }
      if (ln === 'END:VEVENT') { if (cur) evs.push(cur); cur = null; continue; }
      if (!cur) continue;
      const i = ln.indexOf(':'); if (i < 0) continue;
      cur[ln.slice(0, i).split(';')[0].toUpperCase()] = ln.slice(i + 1);
    }
    return evs.map((e, i) => ({ id: e.UID || 'e' + i, summary: unesc(e.SUMMARY), location: unesc(e.LOCATION), description: unesc(e.DESCRIPTION), start: { dateTime: icsDate(e.DTSTART) } })).filter(e => e.start.dateTime);
  }
  async function listEvents(a) {
    const url = (loadCfg().icsUrl || '').replace(/^webcal:/i, 'https:');
    if (!url) return { events: [] };
    if (icsCache.url !== url || Date.now() - icsCache.at > 5 * 60 * 1000) {
      const r = await fetch(url); if (!r.ok) throw err('calendar_unavailable', 'Calendrier inaccessible');
      icsCache = { at: Date.now(), url, events: parseICS(await r.text()) };
    }
    const s = a.startTime || '', e = a.endTime || '9999';
    return { events: icsCache.events.filter(x => x.start.dateTime >= s && x.start.dateTime < e).sort((x, y) => x.start.dateTime < y.start.dateTime ? -1 : 1) };
  }

  /* ---------- HTTP ---------- */
  const readBody = req => new Promise((res, rej) => { let b = ''; req.on('data', d => { b += d; if (b.length > 12e6) { rej(err('too_big')); req.destroy(); } }); req.on('end', () => res(b)); });
  const isLocal = req => /^(::1|127\.0\.0\.1|::ffff:127\.0\.0\.1)$/.test(req.socket.remoteAddress || '');
  const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };

  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    try {
      if (u.pathname.startsWith('/api/')) {
        const cfg = loadCfg();
        if (u.pathname === '/api/ping') return send(res, 200, { ok: true, needsCode: !!cfg.accessCode, version: opts.version || '' });
        if (u.pathname === '/api/config') {
          if (!isLocal(req)) return send(res, 403, { code: 'local_only', message: 'Configuration accessible uniquement depuis le PC serveur' });
          if (req.method === 'GET') return send(res, 200, { email: cfg.email, hasPassword: !!cfg.appPassword, clubEmail: cfg.clubEmail, hasClubPassword: !!cfg.clubPassword, clubQuery: cfg.clubQuery, defaultClubQuery: DEFAULT_CLUB_QUERY, icsUrl: cfg.icsUrl, accessCode: cfg.accessCode, updateRepo: cfg.updateRepo, version: opts.version || '', port: cfg.port });
          const b = JSON.parse(await readBody(req) || '{}');
          const n = { ...cfg, email: (b.email || '').trim(), clubEmail: (b.clubEmail || '').trim(), clubQuery: (b.clubQuery || '').trim(), icsUrl: (b.icsUrl || '').trim(), accessCode: (b.accessCode || '').trim(), updateRepo: (b.updateRepo || '').trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\/+$/, '') };
          if (b.appPassword) n.appPassword = String(b.appPassword).replace(/\s+/g, '');
          if (b.clubPassword) n.clubPassword = String(b.clubPassword).replace(/\s+/g, '');
          fs.writeFileSync(cfgFile, JSON.stringify(n, null, 2)); icsCache.at = 0;
          return send(res, 200, { ok: true });
        }
        if (u.pathname === '/api/update') {
          if (!isLocal(req)) return send(res, 403, { code: 'local_only', message: 'Réservé au PC serveur' });
          if (!opts.updater) return send(res, 400, { code: 'no_updater', message: 'Mises à jour indisponibles dans ce mode' });
          const b = JSON.parse(await readBody(req) || '{}');
          try { return send(res, 200, b.action === 'install' ? await opts.updater.installBase64(b.data) : await opts.updater.check()); }
          catch (e) { return send(res, 400, { code: 'update_failed', message: e.message }); }
        }
        if (cfg.accessCode && req.headers['x-code'] !== cfg.accessCode) return send(res, 401, { code: 'unauthorized', message: 'Code d’accès requis' });
        if (u.pathname === '/api/db') {
          const c = u.searchParams.get('c') || '', id = u.searchParams.get('id');
          if (!c) return send(res, 400, { code: 'bad_request' });
          if (req.method === 'GET') return send(res, 200, { docs: Object.entries(db[c] || {}).map(([k, v]) => ({ id: k, data: v })) });
          if (!id) return send(res, 400, { code: 'bad_request' });
          if (req.method === 'PUT') { (db[c] = db[c] || {})[id] = JSON.parse(await readBody(req) || '{}'); save(); return send(res, 200, { ok: true }); }
          if (req.method === 'DELETE') { if (db[c]) delete db[c][id]; save(); return send(res, 200, { ok: true }); }
        }
        if (u.pathname === '/api/mcp' && req.method === 'POST') {
          const b = JSON.parse(await readBody(req) || '{}'), a = b.args || {};
          try {
            let payload;
            if (b.server === 'Gmail' && b.tool === 'search_threads') payload = await searchThreads(a);
            else if (b.server === 'Gmail' && b.tool === 'unlabel_thread') payload = await markRead(a);
            else if (b.server === 'Gmail' && b.tool === 'send_message') payload = await sendMessage(a);
            else if (b.server === 'Facture' && b.tool === 'send_invoice') payload = await sendInvoice(a);
            else if (b.server === 'Google Calendar' && b.tool === 'list_events') payload = await listEvents(a);
            else throw err('unknown_tool', 'Outil inconnu');
            return send(res, 200, { payload });
          } catch (e) { try { fs.appendFileSync(path.join(dataDir, 'erreurs.log'), new Date().toISOString() + ' ' + b.server + '/' + b.tool + ' ' + (e.code || '') + ' ' + e.message + '\n'); } catch {} return send(res, 400, { code: e.code || 'error', message: e.message }); }
        }
        return send(res, 404, { code: 'not_found' });
      }
      if (u.pathname === '/qr') {
        const port = loadCfg().port || 3300;
        const urls = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => `http://${i.address}:${port}`);
        const QR = require('qrcode');
        const blocks = await Promise.all(urls.map(async x => `<div class="c"><img src="${await QR.toDataURL(x, { margin: 2, width: 260 })}"><div><b>${x}</b></div></div>`));
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        return res.end('<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MCG Pilotage sur iPhone</title><style>body{background:#0d0d0d;color:#f5f5f5;font:16px system-ui;padding:20px;max-width:560px;margin:auto}h1{color:#ffd60a}.c{background:#1a1a1a;border:1px solid #3b3412;border-radius:12px;padding:12px;margin:12px 0;text-align:center}img{background:#fff;border-radius:8px}li{margin:6px 0}</style><h1>📱 MCG Pilotage sur iPhone</h1><ol><li>iPhone sur le <b>même Wi-Fi</b> que ce PC.</li><li>Ouvre l’appareil photo de l’iPhone et scanne le code (si plusieurs, essaie le premier).</li><li>Ouvre le lien dans <b>Safari</b>, entre le code d’accès.</li><li>Bouton Partager &gt; <b>Sur l’écran d’accueil</b> &gt; Ajouter.</li></ol>' + (blocks.join('') || '<p>Aucun réseau détecté : connecte le PC au Wi-Fi.</p>'));
      }
      // fichiers statiques
      let p = u.pathname === '/' ? '/index.html' : u.pathname;
      if (p === '/admin') p = '/admin.html';
      const pub = path.join(root, 'public'), f = path.normalize(path.join(pub, p));
      if (!f.startsWith(pub)) { res.writeHead(403); return res.end(); }
      fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end('Introuvable'); } res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); res.end(d); });
    } catch (e) { send(res, 500, { code: 'server_error', message: e.message }); }
  });

  return {
    start() {
      const port = loadCfg().port || 3300;
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, '0.0.0.0', () => {
          const ips = Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => `http://${i.address}:${port}`);
          resolve({ port, urls: ips });
        });
      });
    },
    stop() { server.close(); }
  };
}

module.exports = { createServer, DEFAULT_CLUB_QUERY };

if (require.main === module) {
  const dir = process.env.MCG_DATA || path.join(__dirname, 'data');
  createServer(dir).start().then(i => { console.log('MCG Pilotage démarré.'); console.log('Sur ce PC : http://localhost:' + i.port); i.urls.forEach(u => console.log('Sur le réseau : ' + u)); })
    .catch(e => { console.error('Erreur au démarrage :', e.message); process.exit(1); });
}
